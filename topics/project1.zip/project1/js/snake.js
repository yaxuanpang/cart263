class Snake {
    //constructor for the snake (position, size)
    constructor(x, y, size = 20) {
        this.parent = document.querySelector("#parent");
        this.size = size;
        this.speedX = 0;
        this.speedY = 0;
        this.segments = [{ x, y }];
        this.elements = []; // array of boxes for the snake body

        this.addSegmentElement(); // added a segment element for the snake

        //animate function
        this.animate();
    }

    // append this to the box
    addSegmentElement() {
        const div = document.createElement("div");
        div.classList.add("box");
        this.parent.appendChild(div);
        this.elements.push(div);
    }

    damage() {
        if (this.segments.length > 1) { // don't remove the head
            this.segments.pop(); // remove last square

            const lastElement = this.elements.pop(); // remove last DOM element
            lastElement.remove(); // remove from the page
        }
        else {
            this.reset(window.currentBirds); // makes all the birds currenlty on the screen disappear
        }
    }

    grow() { // add one more square at the back
        const tail = this.segments[this.segments.length - 1]; // everything is delayed by one square
        this.segments.push(Object.assign({}, tail));
        this.addSegmentElement(); // adds the square
    }


    //move function
    move() {
        for (let i = this.segments.length - 1; i > 0; i--) {
            this.segments[i] = Object.assign({}, this.segments[i - 1]);
        }

        this.segments[0].x += this.speedX;
        this.segments[0].y += this.speedY;

        //makes sure the snakes stays within the borders and resets if the snake 
        //gets out of the borders
        const maxX = Math.floor(this.parent.clientWidth / this.size) - 1;
        const maxY = Math.floor(this.parent.clientHeight / this.size) - 1;

        //if the snake gets out of the borders, all the birds on the screen reset (go back to 0)
        if (this.segments[0].x < 0 || this.segments[0].x > maxX ||
            this.segments[0].y < 0 || this.segments[0].y > maxY) {
            this.reset(window.currentBirds);
        }
    }

    // snake's original position and resets the whole game
    reset(birds) {
        this.segments = [{ x: 10, y: 10 }];
        this.elements.slice(1).forEach(el => el.remove());
        this.elements = [this.elements[0]];
        this.speedX = 0;
        this.speedY = 0;
        this.resetSnake = true;
        birds.forEach(bird => bird.birdElement.remove());
        birds.length = 0;


        //game over page
        const gameOver = document.getElementById("gameOver");
        gameOver.style.display = "flex";

    }

    //checks for the collision between the snake and the targets
    checkCollision(object, type) {

        // calculating the number of grid squares apart the snake's 
        // head is from the object horizontally and vertically
        const dx = Math.abs(this.segments[0].x - object.x);
        const dy = Math.abs(this.segments[0].y - object.y);

        //checks if the snake's head is on the same square
        if (
            (dx === 0 && dy === 0)
        ) {

            //if the snake eats a target, it adds a square and if it eats a bird takes off a square
            //both objects relocate after they are eaten
            if (type === "target") {
                this.grow();
            }

            if (type === "bird") {
                this.damage();
            }

            object.relocate();

            return true;
        }
        return false;
    }

    //function animate that handles the event listeners
    animate() {
        //Event listener to move the snake
        window.addEventListener("keydown", (e) => {
            if (e.key === "ArrowRight" && this.speedX !== -1) { this.speedX = 1; this.speedY = 0; }
            if (e.key === "ArrowLeft" && this.speedX !== 1) { this.speedX = -1; this.speedY = 0; }
            if (e.key === "ArrowUp" && this.speedY !== 1) { this.speedX = 0; this.speedY = -1; }
            if (e.key === "ArrowDown" && this.speedY !== -1) { this.speedX = 0; this.speedY = 1; }
        });
    }

    //render function
    renderSnake() {
        this.segments.forEach((seg, i) => {
            this.elements[i].style.left = (seg.x * this.size) + "px";
            this.elements[i].style.top = (seg.y * this.size) + "px";
            this.elements[i].style.width = this.size + "px";
            this.elements[i].style.height = this.size + "px";
        });
    }

}
